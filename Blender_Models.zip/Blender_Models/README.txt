Models exported from the PerfectGold Editor can't be opened in Blender. I used Noesis to convert the models so they can be opened in Blender. I appended "FIXED - " to the converted models.

This will allow you to create custom characters using Blender.

Some issues:
 * UV mapping is messed up (thank Nintendo / the editor)
 * No bones, just joints.
 * No Special parts (Fox's gun etc)